#!/bin/bash

# Navigate to the example directory
cd ~/Documents/MMW-HAT-Release/example_1_full_vis || exit

# Run the example
python run_example_vis.py
